package com.nice.istudy.entity;

import java.util.Date;

/*
 create table problem (
 id int unsigned not null auto_increment primary key,
 type int not null,
 title varchar(30),
 content text,
 author varchar(10),
 writeTime date
) engine InnoDB charset utf8;
 */

public class Problem {
	int id;
	int type;
	String title;
	String text;
	String author;
	Date writeTime; 
}
