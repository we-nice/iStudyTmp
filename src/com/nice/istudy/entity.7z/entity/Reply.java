package com.nice.istudy.entity;

import java.util.Date;

/*
 create table reply (
 id int unsigned not null auto_increment primary key,
 author varchar(30) ,
 problemID int not null,
 content text,
 isExcellent tinyint(1),
 writeTime date
) engine InnoDB charset utf8;

 */
public class Reply {
	int id;
	String author;
	int problemID;
	String text;
	int isExcellent;
	Date writeTime;
}
