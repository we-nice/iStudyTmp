package com.nice.istudy.entity;
/*
 create table file (
 id int unsigned not null auto_increment primary key,
 name varchar(20) not null,
 description varchar(30),
 size int,
 author varchar(10),
 isDel tinyint(1),
 src varchar(30),
 college int not null,
 subject int not null
) engine InnoDB charset utf8;
 */
public class File {
	int id;
	String name;
	String description;
	int size;
	String author;
	int isDel;
	String src;
	int college;
	int subject;
}
