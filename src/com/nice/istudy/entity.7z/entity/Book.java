package com.nice.istudy.entity;


/*
 *  id int unsigned not null auto_increment primary key,
 bookId varchar(20) not null unique key,
 bookName varchar(30),
 typeId int not null,
 author varchar(10),
 price int,
 total int,
 loan_num int,
 desciption varchar(255),
 isRecommend tinyint(1),
 book_imgsrc varchar(30)
 * */

public class Book {
	int id;
	String bookName;
	int typeId;
	String author;
	int price;
	int total;
	int loan_num;
	String description;
	int isRecommend;
	String book_imgsrc;
}
