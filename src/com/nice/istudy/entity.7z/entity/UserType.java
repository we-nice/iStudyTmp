package com.nice.istudy.entity;

/*
 create table userType (
id int unsigned not null auto_increment primary key,
name varchar(20) not null,
modifyUser int not null
) engine InnoDB charset utf8;

 */

public class UserType {
	int id;
	String name;
	int modifyUser;
}
