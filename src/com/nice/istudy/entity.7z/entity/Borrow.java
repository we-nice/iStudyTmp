package com.nice.istudy.entity;

import java.util.Date;

/*
create table borrow (
 id int unsigned not null auto_increment primary key,
 bookId varchar(20) not null unique key,
 bookName varchar(30),
 startTime date,
 lastTime date,
 studentNo char(9) not null,
 book_num int,
 isReturn tinyint(1)
) engine InnoDB charset utf8;
 */



public class Borrow {
	int id;
	String bookId;
	String bookName;
	Date startTime;
	Date lastTime;
	String studentNo;
	int book_num;
	int isReturn;
}


