package com.nice.istudy.entity;

/*
create table collegeType (
id int unsigned not null auto_increment primary key,
name varchar(20) not null,
modifyUser int not null,
father int not null default 0
) engine InnoDB charset utf8;
 */

public class CollegeType {
	int id;
	String name;
	int modifyUser;
	int father;
}
